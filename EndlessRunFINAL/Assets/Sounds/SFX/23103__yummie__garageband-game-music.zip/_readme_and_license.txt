Sound pack downloaded from Freesound
----------------------------------------

"Garageband Game Music"

This pack of sounds contains sounds by the following user:
 - yummie ( https://freesound.org/people/yummie/ )

You can find this pack online at: https://freesound.org/people/yummie/packs/23103/


Pack description
----------------

Stuff I composed for a game (bachelors thesis media computer science). If you want to use it, please leave my name and a backlink somewhere (youtube, website, credits...):

Music: Manuel F. Graf, www.manuelgraf.com


Licenses in this pack (see below for individual sound licenses)
---------------------------------------------------------------

Attribution 4.0: https://creativecommons.org/licenses/by/4.0/


Sounds in this pack
-------------------

  * 410578__yummie__game-win-screen-background-music.mp3
    * url: https://freesound.org/s/410578/
    * license: Attribution 4.0
  * 410576__yummie__game-lobby-screen-background-music.mp3
    * url: https://freesound.org/s/410576/
    * license: Attribution 4.0
  * 410575__yummie__game-losing-screen-background-music.mp3
    * url: https://freesound.org/s/410575/
    * license: Attribution 4.0
  * 410574__yummie__game-background-music-loop-short.mp3
    * url: https://freesound.org/s/410574/
    * license: Attribution 4.0


